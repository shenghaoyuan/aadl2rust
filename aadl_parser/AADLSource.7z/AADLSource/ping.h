#ifndef __PING_H_
#define __PING_H_
#include <stdint.h>

typedef int64_t custom_int;
#endif

void user_do_ping_spg(long long *v);
void user_ping_spg(long long i);
void recover(void);