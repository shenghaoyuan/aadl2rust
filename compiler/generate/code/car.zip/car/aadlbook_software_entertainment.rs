// 自动生成的 Rust 代码 - 来自 AADL 模型
// 生成时间: 2025-09-19 17:00:16

#![allow(unused_imports)]
use std::sync::{mpsc, Arc};
use std::sync::Mutex;
use std::thread;
use std::time::{Duration, Instant};
use lazy_static::lazy_static;
use std::collections::HashMap;
use libc::{
    pthread_self, sched_param, pthread_setschedparam, SCHED_FIFO,
    cpu_set_t, CPU_SET, CPU_ZERO, sched_setaffinity,
};
include!(concat!(env!("OUT_DIR"), "/aadl_c_bindings.rs"));

// ---------------- cpu ----------------
fn set_thread_affinity(cpu: isize) {
    unsafe {
        let mut cpuset: cpu_set_t = std::mem::zeroed();
        CPU_ZERO(&mut cpuset);
        CPU_SET(cpu as usize, &mut cpuset);
        sched_setaffinity(0, std::mem::size_of::<cpu_set_t>(), &cpuset);
    }
}

// AADL Process: entertainment
#[derive(Debug)]
pub struct entertainmentProcess {
    // Port: music_in In
    pub music_in: Option<mpsc::Receiver<music>>,
    // Port: contacts In
    pub contacts: Option<mpsc::Receiver<contacts>>,
    // Port: infos Out
    pub infos: Option<mpsc::Sender<entertainment_infos>>,
    // Port: music_out Out
    pub music_out: Option<mpsc::Sender<music>>,
    // 进程 CPU ID
    pub cpu_id: isize,
    // 内部端口: music_in In
    pub music_inSend: Option<mpsc::Sender<music>>,
    // 内部端口: contacts In
    pub contactsSend: Option<mpsc::Sender<contacts>>,
    // 内部端口: infos Out
    pub infosRece: Option<mpsc::Receiver<entertainment_infos>>,
    // 内部端口: music_out Out
    pub music_outRece: Option<mpsc::Receiver<music>>,
    // 子组件线程（thr : thread entertainment_thr）
    #[allow(dead_code)]
    pub thr: entertainment_thrThread,
}

impl entertainmentProcess {
    // Creates a new process instance
    pub fn new(cpu_id: isize) -> Self {
        let mut thr: entertainment_thrThread = entertainment_thrThread::new(cpu_id);
        let mut music_inSend = None;
        let mut contactsSend = None;
        let mut infosRece = None;
        let mut music_outRece = None;
        let channel = mpsc::channel();
        music_inSend = Some(channel.0);
        // build connection: 
            thr.music_in = Some(channel.1);
        let channel = mpsc::channel();
        contactsSend = Some(channel.0);
        // build connection: 
            thr.contacts = Some(channel.1);
        let channel = mpsc::channel();
        // build connection: 
            thr.infos = Some(channel.0);
        infosRece = Some(channel.1);
        let channel = mpsc::channel();
        // build connection: 
            thr.music_out = Some(channel.0);
        music_outRece = Some(channel.1);
        return Self { music_in: None, music_inSend, contacts: None, contactsSend, infos: None, infosRece, music_out: None, music_outRece, thr, cpu_id }  //显式return;
    }
    
    // Starts all threads in the process
    pub fn start(self: Self) -> () {
        let Self { music_in, music_inSend, contacts, contactsSend, infos, infosRece, music_out, music_outRece, thr, cpu_id, .. } = self;
        thread::Builder::new()
            .name("thr".to_string())
            .spawn(|| { thr.run() }).unwrap();
        let music_in_rx = music_in.unwrap();
        thread::Builder::new()
            .name("data_forwarder_music_in".to_string())
            .spawn(move || {
            loop {
                if let Ok(msg) = music_in_rx.try_recv() {
                    if let Some(tx) = &music_inSend {
                        let _ = tx.send(msg);
                    };
                };
                std::thread::sleep(std::time::Duration::from_millis(1));
            };
        }).unwrap();
        let contacts_rx = contacts.unwrap();
        thread::Builder::new()
            .name("data_forwarder_contacts".to_string())
            .spawn(move || {
            loop {
                if let Ok(msg) = contacts_rx.try_recv() {
                    if let Some(tx) = &contactsSend {
                        let _ = tx.send(msg);
                    };
                };
                std::thread::sleep(std::time::Duration::from_millis(1));
            };
        }).unwrap();
        let infosRece_rx = infosRece.unwrap();
        thread::Builder::new()
            .name("data_forwarder_infosRece".to_string())
            .spawn(move || {
            loop {
                if let Ok(msg) = infosRece_rx.try_recv() {
                    if let Some(tx) = &infos {
                        let _ = tx.send(msg);
                    };
                };
                std::thread::sleep(std::time::Duration::from_millis(1));
            };
        }).unwrap();
        let music_outRece_rx = music_outRece.unwrap();
        thread::Builder::new()
            .name("data_forwarder_music_outRece".to_string())
            .spawn(move || {
            loop {
                if let Ok(msg) = music_outRece_rx.try_recv() {
                    if let Some(tx) = &music_out {
                        let _ = tx.send(msg);
                    };
                };
                std::thread::sleep(std::time::Duration::from_millis(1));
            };
        }).unwrap();
    }
    
}

// AADL Thread: entertainment_thr
#[derive(Debug)]
pub struct entertainment_thrThread {
    // Port: music_in In
    pub music_in: Option<mpsc::Receiver<music>>,
    // Port: contacts In
    pub contacts: Option<mpsc::Receiver<contacts>>,
    // Port: infos Out
    pub infos: Option<mpsc::Sender<entertainment_infos>>,
    // Port: music_out Out
    pub music_out: Option<mpsc::Sender<music>>,
    // 结构体新增 CPU ID
    pub cpu_id: isize,
    
    // --- AADL属性 ---
    pub dispatch_protocol: String, // AADL属性: Dispatch_Protocol
    pub period: u64, // AADL属性: Period
    pub mipsbudget: f64, // AADL属性: mipsbudget
}

impl entertainment_thrThread {
    // 创建组件并初始化AADL属性
    pub fn new(cpu_id: isize) -> Self {
        Self {
            music_in: None,
            contacts: None,
            infos: None,
            music_out: None,
            cpu_id: cpu_id,
            dispatch_protocol: "Periodic".to_string(), // AADL属性: Dispatch_Protocol
            period: 5, // AADL属性: Period
            mipsbudget: 5, // AADL属性: mipsbudget
        }
    }
}
