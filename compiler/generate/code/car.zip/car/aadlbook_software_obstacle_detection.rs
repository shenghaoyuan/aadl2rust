// 自动生成的 Rust 代码 - 来自 AADL 模型
// 生成时间: 2025-09-19 17:00:16

#![allow(unused_imports)]
use std::sync::{mpsc, Arc};
use std::sync::Mutex;
use std::thread;
use std::time::{Duration, Instant};
use lazy_static::lazy_static;
use std::collections::HashMap;
use libc::{
    pthread_self, sched_param, pthread_setschedparam, SCHED_FIFO,
    cpu_set_t, CPU_SET, CPU_ZERO, sched_setaffinity,
};
include!(concat!(env!("OUT_DIR"), "/aadl_c_bindings.rs"));

// ---------------- cpu ----------------
fn set_thread_affinity(cpu: isize) {
    unsafe {
        let mut cpuset: cpu_set_t = std::mem::zeroed();
        CPU_ZERO(&mut cpuset);
        CPU_SET(cpu as usize, &mut cpuset);
        sched_setaffinity(0, std::mem::size_of::<cpu_set_t>(), &cpuset);
    }
}

// AADL Process: obstacle_detection
#[derive(Debug)]
pub struct obstacle_detectionProcess {
    // Port: camera In
    pub camera: Option<mpsc::Receiver<obstacle_position>>,
    // Port: radar In
    pub radar: Option<mpsc::Receiver<obstacle_position>>,
    // Port: obstacle_position Out
    pub obstacle_position: Option<mpsc::Sender<obstacle_position>>,
    // 进程 CPU ID
    pub cpu_id: isize,
    // 内部端口: camera In
    pub cameraSend: Option<mpsc::Sender<obstacle_position>>,
    // 内部端口: radar In
    pub radarSend: Option<mpsc::Sender<obstacle_position>>,
    // 内部端口: obstacle_position Out
    pub obstacle_positionRece: Option<mpsc::Receiver<obstacle_position>>,
    // 子组件线程（thr : thread obstacle_detection_thr）
    #[allow(dead_code)]
    pub thr: obstacle_detection_thrThread,
}

impl obstacle_detectionProcess {
    // Creates a new process instance
    pub fn new(cpu_id: isize) -> Self {
        let mut thr: obstacle_detection_thrThread = obstacle_detection_thrThread::new(cpu_id);
        let mut cameraSend = None;
        let mut radarSend = None;
        let mut obstacle_positionRece = None;
        let channel = mpsc::channel();
        cameraSend = Some(channel.0);
        // build connection: 
            thr.camera = Some(channel.1);
        let channel = mpsc::channel();
        radarSend = Some(channel.0);
        // build connection: 
            thr.radar = Some(channel.1);
        let channel = mpsc::channel();
        // build connection: 
            thr.obstacle_detected = Some(channel.0);
        obstacle_positionRece = Some(channel.1);
        return Self { camera: None, cameraSend, radar: None, radarSend, obstacle_position: None, obstacle_positionRece, thr, cpu_id }  //显式return;
    }
    
    // Starts all threads in the process
    pub fn start(self: Self) -> () {
        let Self { camera, cameraSend, radar, radarSend, obstacle_position, obstacle_positionRece, thr, cpu_id, .. } = self;
        thread::Builder::new()
            .name("thr".to_string())
            .spawn(|| { thr.run() }).unwrap();
        let camera_rx = camera.unwrap();
        thread::Builder::new()
            .name("data_forwarder_camera".to_string())
            .spawn(move || {
            loop {
                if let Ok(msg) = camera_rx.try_recv() {
                    if let Some(tx) = &cameraSend {
                        let _ = tx.send(msg);
                    };
                };
                std::thread::sleep(std::time::Duration::from_millis(1));
            };
        }).unwrap();
        let radar_rx = radar.unwrap();
        thread::Builder::new()
            .name("data_forwarder_radar".to_string())
            .spawn(move || {
            loop {
                if let Ok(msg) = radar_rx.try_recv() {
                    if let Some(tx) = &radarSend {
                        let _ = tx.send(msg);
                    };
                };
                std::thread::sleep(std::time::Duration::from_millis(1));
            };
        }).unwrap();
        let obstacle_positionRece_rx = obstacle_positionRece.unwrap();
        thread::Builder::new()
            .name("data_forwarder_obstacle_positionRece".to_string())
            .spawn(move || {
            loop {
                if let Ok(msg) = obstacle_positionRece_rx.try_recv() {
                    if let Some(tx) = &obstacle_position {
                        let _ = tx.send(msg);
                    };
                };
                std::thread::sleep(std::time::Duration::from_millis(1));
            };
        }).unwrap();
    }
    
}

// AADL Thread: obstacle_detection_thr
#[derive(Debug)]
pub struct obstacle_detection_thrThread {
    // Port: camera In
    pub camera: Option<mpsc::Receiver<obstacle_position>>,
    // Port: radar In
    pub radar: Option<mpsc::Receiver<obstacle_position>>,
    // Port: obstacle_detected Out
    pub obstacle_detected: Option<mpsc::Sender<obstacle_position>>,
    // 结构体新增 CPU ID
    pub cpu_id: isize,
    
    // --- AADL属性 ---
    pub dispatch_protocol: String, // AADL属性: Dispatch_Protocol
    pub period: u64, // AADL属性: Period
    pub mipsbudget: f64, // AADL属性: mipsbudget
}

impl obstacle_detection_thrThread {
    // 创建组件并初始化AADL属性
    pub fn new(cpu_id: isize) -> Self {
        Self {
            camera: None,
            radar: None,
            obstacle_detected: None,
            cpu_id: cpu_id,
            dispatch_protocol: "Periodic".to_string(), // AADL属性: Dispatch_Protocol
            period: 100, // AADL属性: Period
            mipsbudget: 10, // AADL属性: mipsbudget
        }
    }
}
