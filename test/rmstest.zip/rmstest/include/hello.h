#ifndef USER_HELLO_SPG_H
#define USER_HELLO_SPG_H

// 声明第一个任务的函数
void user_hello_spg_1(void);

// 声明第二个任务的函数
void user_hello_spg_2(void);

#endif /* USER_HELLO_SPG_H */