#include <stdio.h>

void user_hello_spg_1 (void)
{
        printf ("FIRST TASK\n");
        fflush (stdout);
}

void user_hello_spg_2 (void)
{
        printf ("SECOND TASK\n");
        fflush (stdout);
}